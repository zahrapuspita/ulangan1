<?php

$host = "localhost";
$user = "root";
$pass = "";
$db	  = "crud";

$dbconnect = new mysqli("$host","$user","$pass","$db");

?>